$results = import-csv .\organizations-1000.csv
$zquery = $args[0]
$output = $results | Where-Object Industry -like $zquery
$output

